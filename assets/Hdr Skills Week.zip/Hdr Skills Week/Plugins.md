Plugins extend the functionality of [[Obsidian]]. There are two varieties of plugin: those developmed and maintained by the Obsidian developers are called *Core* plugins, and those developed and maintained by 

## Core plugins

## Community plugins

> There are so many! How do I choose?

Why not have a look at: 
- How popular they are
- Whether they are properly maintained
- Whether they will fit in with your workflow

Here are some community plugins that I find invaluable:

- Dataview
- Periodic notes
- Auto Note Mover
- Calendar
- [Zotero integration](https://github.com/mgmeyers/obsidian-zotero-integration) (you need to add some plugins to Zotero to make it work)
- Pandoc (you need to also have Pandoc installed)
- QuickAdd
- Templater
- Dynamic Table of Contents

