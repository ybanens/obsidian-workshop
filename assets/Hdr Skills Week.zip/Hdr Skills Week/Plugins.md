Plugins extend the funcitonality of [[Obsidian]]. 

> But there are so many! How do I choose?

Why not have a look at: 
- How popular they are
- Whether they are properly maintained
- Whether they will fit in with your workflow

Here are some great community plugins we will be discussing today:

- Dataview
- Periodic notes
- Auto Note Mover
- Calendar
- [Zotero integration](https://github.com/mgmeyers/obsidian-zotero-integration) (you need to add some plugins to Zotero to make it work)
- Pandoc (you need to also have Pandoc installed)
- QuickAdd
- Templater
- Dynamic Table of Contents

