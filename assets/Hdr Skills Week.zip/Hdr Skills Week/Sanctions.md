---
alias:
- 'unilateral coercive measures'
- 'Autonomous sanctions'
- 'Unilateral sanctions'
- 'Coercive measures'
- 'Economic measures'
---

#concept
#law/international 

## Origin of sanctions

The word 'sanction' has its origins in the Latin 'sacere', meaning 'to set apart'. According to [[Homo Sacer]], the 'sacred man' was one who had been 'set apart' from society and had no rights as a human. Hence, they could be killed without attracting a charge of murder, since no 'human' had been killed. To be 'sanctified' in a religious sense is another aspect to the same term. A 'sacred' object is one that has been 'set apart' for special reverence or treatment. 

Hence also the term 'sanction' when used as a verb can mean opposite things, both deriving from the same idea. One may have the Church's sanction (i.e. its approval) to proceed with a course of action, or one may be sanctioned (i.e. punished) by that same Church when its rules have been transgressed. 

## Multilateral vs unilateral sanctions

One way to distinguish between types of international sanctions is to consider the basis for their imposition. They might be 

### Multilateral sanctions

Sanctions instituted against countries under the auspices of a multilateral body like the United Nations are considered to be multilateral. Their legality comes from the law of treaties (e.g. the Vienna Convention and customary law principles like *pacta sunt servanda*). States agree to co-operate with the imposition of sanctions when they accede to membership of the organisation. 

### Unilateral sanctions

Sancitons levied unilaterally by a state without direction or authorisation from the UN are called unilateral or 'autonomous' sanctions. Their legality is much less well established. It is arguable that there is a legal basis for them under [[Principles of State Responsibility]] when a 'wronged state' uses them to induce another state to cease behaviour that is internatinally wrongful. In cases where a state is simply attempting to exert political and economic pressure in pursuit of its own interests, such sanctions are not considered to have a legal justification under international law. 

## Comprehensive vs targeted vs individual sanctions

Having developed 