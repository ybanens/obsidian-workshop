A quote looks like this: 

> Writing is thinking, only more slowly. 

A callout looks like this: 

> [!NOTE] Writing is thinking
> Only more slowly

#concept 

