```toc
```

## Integrations

**Drafts**
A popular text-processing app for Mac that uses [[Markdown]] and integrates with many other tools. 
- [Using Obsidian with Drafts](https://forums.getdrafts.com/t/using-obsidian-with-drafts/11221)

## Academic writing

Practical writing Tips for Manuscript Writing, Posters, and exporting citations to Word, PDF, and Latex
- [Obsidian Tutorial for Aademic Writing](https://betterhumans.pub/obsidian-tutorial-for-academic-writing-87b038060522)

