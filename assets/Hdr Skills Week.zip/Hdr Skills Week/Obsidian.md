---
alias: 'About obsidian'
---

## What is Obsidian?

Obsidian is a text-based, extensible personal knowledge management system that sits on a folder of [[Markdown]] files. Its main feature is the ease of linking and the ability to extend it through plugins.

## Who is Obsidian for?

[Elizabeth Butler](https://elizabethbutlermd.com/obsidian-notes/) suggests it's ideal for writers, students and academics. Anyone in the knowledge field, really. That might be lawyers, programers, etc. 

You can extend Obsidian with [[Plugins]]. 