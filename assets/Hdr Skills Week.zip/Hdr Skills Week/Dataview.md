## What is Dataview? 

[Dataview](https://blacksmithgu.github.io/obsidian-dataview/) is probably the most powerful plugin available for Obsidian. It's not necessary to install it to use Obsidian but it makes finding and organising your work much easier. 

See the example below:

```dataview
LIST FROM #concept 
SORT BY NAME ASC
```

---

## Resources

The official page for Dataview is here: https://blacksmithgu.github.io/obsidian-dataview/

There is a handy Dataview query builder here: https://s-blu.github.io/basic-dataview-query-builder/

