#concept 

### Basic Markdown

Markdown is an easy to read formatting syntax that works with plain text. 

| Type | To get          |
| ----:| --------------- |
|    # | Heading 1       |
|   ##   | Heading 2       |
|  ### | Heading 3       |
|    - | Bulleted list   |
|    1 | Numbered list   |
|   [ ] | Checkbox        |
|  --- | Horizontal line |

Try it out on this page!