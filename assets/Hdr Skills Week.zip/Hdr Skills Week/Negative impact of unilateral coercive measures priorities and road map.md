#readingnote
#law/international 

Discusses the challenges to the international relations posed by so-called [[Sanctions|unilateral coercive measures]] (i.e. uniliateral sanctions). 

Mentions at [42] the introduction of Magnitsky sanctions in multiple jurisdictions and alludes to the 'selectivity and double standards that arise when such sanctions are introduced in the absence of any valid legal ground'.
