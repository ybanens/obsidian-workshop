---
date: 2023-05-23
topic: 'YAML'
tags: '#concept'
---


> [!NOTE] YAML's Origin Story
> YAML used to stand for 'Yet Another Markup Language'. Nowadays, it stands for 'YAML Ain't Markup Language'. 

YAML is there for storing metadata (information about your pages) *in* your pages. For example, the dates it was created and edited, the type of page, any tags you want to include etc. 

YAML is stored in a `code block` at the top of the page. You can see how the syntax works from the example on this page. There is a `key`, like 'date' or 'topic', and there is a `value` (or set of values) that goes with it. 

YAML helps you to to organise and find your pages. You don't have to use it though, and Obsidian is very forgiving if you get it wrong. It will still display your pages even if the YAML isn't formatted properly. You can get [[Plugins]] to 