Backlinks are a key feature of Obsidian. They help you to find other pages in your vault that refer to the page you're writing. This is incredibly useful for building a set of interlinked notes.

#concept 

