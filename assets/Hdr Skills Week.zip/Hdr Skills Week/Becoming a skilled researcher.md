Becoming a skilled researcher involves so many skills, many of which I had never even contemplated when I started out! I had thought that it boiled down to the ability to use [[Database searching|clever database searching]] techniques and find obscure articles. Boy, was I wrong! There was so much more to it. As far as literature went, I needed to be able to read fast and extract information, to synthesise properly, and to make connections between ideas. I had to learn to [[Writing|write concisely]]. I also needed other skills, like time and project management. On top of all that, I needed to learn excellent people and communication skills so I could maintain good relationships with my supervisor, other students, the faculty and with colleagues from other institutions. 

One thing I have learned, is that: 

> [!WARNING] Just get something done
> Done is better than perfect!

I am a terrible one for analysis paralysis and for standing frozen before the insurmountable pile of neverending work that looms before every academic. In this regard, blogs like The Thesis Whispererer have been very helpful in adjusting my tension, as it were. 

Another thing I have learned about myself is that

> [!NOTE] How I work
> I think by writing

