---
alias:
- 'Zotero, Obsidian, Pandoc'
- 'Zotero'
---

Obsidian integrates with Zotero[^1] which means you can connect your Obsidian vault to your Zotero database and pull in citations and annotations from articles you've stored in there. 

It take a bit of setting up though. You need to add a couple of plugins to Zotero and then choose one of the plugins to import your Zotero 

## Zotero plugins

- [Better BiBTex](https://retorque.re/zotero-better-bibtex/installation/) - periodically exports your Zotero database to a file that Obsidian can read
- [MarkDB Connect](https://github.com/daeh/zotero-markdb-connect) - highlights which Zotero entries have entries in your Obsidian database

## Obsidian plugins

- [Obsidian Zotero Integration](https://github.com/mgmeyers/obsidian-zotero-integration) - allows you to search and insert citations and reading notes into your Obsidian database. 
- [Citations](https://github.com/hans/obsidian-citation-plugin) - similar functionality to the Integration plugin above. Faster and simpler. Go with the Integration one if you want a fuller set of features. 

## Exporting with Pandoc

Pandoc is a popular application for converting documents between formats. It can be used to export your Obsidian notes (which are in [[Markdown]] format) to many other formats, like PDF, Word or LaTeX. The project page is listed below, but you can just search for it in the Community plugins directory. 

- [Project page](https://github.com/OliverBalfour/obsidian-pandoc) 

---

[^1] Unfortunately, Obsidian doesn't integrate with Endnote because Endnote doesn't support plugins, nor can it export its library in BiBTeX format.

