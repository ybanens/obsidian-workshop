---
date created: 
tags:
- '#dailynote'
---

## My focus or intention for today

Write your guiding focus for the day. 

## My agenda

Enter the things you plan to be doing today here. 