From the Latin, roughly translated to 'sacred man', homo sacer is a human who is marked by the sovereign as being beyond the protection of the law, and who therefore may be killed without committing the crime of murder. This #concept was used by Agamben in his book 'Sovereign Power and Bare Life' to represent the ultimate expression of [[biopower]] as demonstrated by the concentration camp. 

#concept 

